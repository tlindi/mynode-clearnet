#!/bin/bash

# This will run prior to launching the application